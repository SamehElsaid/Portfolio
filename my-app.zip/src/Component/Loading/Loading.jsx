import React, { memo } from 'react';
import './Loading.css'
const Loading = memo(() => {
    return (
        <div className='loader'>
        </div>
    );
});

export default Loading;